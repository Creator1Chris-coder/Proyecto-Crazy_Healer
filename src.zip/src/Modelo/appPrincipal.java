/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Vista.loginInMedico;

/**
 *
 * @author joseluis.caamal
 */
public class appPrincipal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       // Inicia la aplicación 10/04/2020
       //Caamal Ic José Luis
        loginInMedico lim = new loginInMedico();
        lim.show(true);
    }
    
}
